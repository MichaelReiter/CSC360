University of Victoria
Fall 2016
CSC 360 Assignment 3
Michael Reiter
V00831568

--------------------------------------------------------------------------

Instructions for Building and Running (for use in a Unix environment)

1. To compile my code, simply execute `make` from the terminal.
2. To run diskinfo, execute `./diskinfo <file system image>` from the terminal.
   To run disklist, execute `./disklist <file system image>` from the terminal.
   To run diskget, execute `./diskget <file system image> <file system image> <file>` from the terminal.
   To run diskput, execute `./diskput <file system image> <file system image> <file>` from the terminal.

--------------------------------------------------------------------------
